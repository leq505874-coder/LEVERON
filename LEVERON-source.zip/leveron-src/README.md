# LEVERON 🎧

App Android **nhận diện bài hát từ âm thanh hệ thống** — không phải app phát nhạc.
Nghe Spotify / YouTube Music / Zing… như bình thường, LEVERON hiển thị bài đang phát và cho bạn tua, phát/dừng, chuyển bài, chỉnh EQ.

## Tính năng
- **Nhận biết bài hát**: đọc MediaSession của app đang phát (tên, nghệ sĩ, ảnh bìa, vị trí, trạng thái) — cần quyền *Truy cập thông báo*.
- **Điều khiển**: tua, phát, dừng, next, prev ngay trong LEVERON.
- **Nhận diện bằng âm thanh** (nút micro): thu ~12 giây âm thanh hệ thống (AudioPlaybackCapture) rồi gửi AudD — dùng khi app nguồn không cung cấp metadata.
- **EQ 10 band** (31 Hz → 16 kHz, ±12 dB) + preset: Flat, Bass, Vocal, Treble, Rock, Pop, EDM, Acoustic.
- **Giao diện đổi màu theo ảnh bìa** bài hát.
- **Video bài hát**: tìm trên YouTube, phát tắt tiếng và tự đồng bộ theo vị trí bài (có nút chỉnh lệch ±0.5s). Không có YouTube key → hiện ảnh bìa.

## Build
Tự động qua GitHub Actions (`.github/workflows/build.yml`) → tải APK ở tab *Actions → Artifacts*.
Secrets (tuỳ chọn, hoặc nhập trong app ở *Cài đặt*):
- `AUDD_API_KEY` — https://dashboard.audd.io
- `YOUTUBE_API_KEY` — YouTube Data API v3

Build local: tạo `local.properties` có `AUDD_API_KEY=...`, `YOUTUBE_API_KEY=...` rồi `gradle assembleDebug` (Gradle 8.5, JDK 17).

## Giới hạn cần biết
- EQ: Android không cho app thường EQ toàn hệ thống. EQ chỉ áp lên app nào chia sẻ audio session (Spotify, YT Music, VLC…).
- Nhận diện bằng âm thanh: app nguồn có thể chặn thu âm (DRM/opt-out).
- Video lệch nhẹ so với âm thanh là bình thường (bản MV khác bản audio) — chỉnh bằng nút ±.
- Bài nhận diện từ âm thanh chỉ để xem, không điều khiển được.
