import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Đọc key từ local.properties / gradle property / biến môi trường (CI).
val localProps = Properties().apply {
    val f = rootProject.file("local.properties")
    if (f.exists()) f.inputStream().use { load(it) }
}
fun secret(name: String): String =
    (localProps.getProperty(name) ?: project.findProperty(name)?.toString() ?: System.getenv(name) ?: "")

android {
    namespace = "com.leveron.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.leveron.app"
        minSdk = 29
        targetSdk = 34
        versionCode = 2
        versionName = "2.0"
        buildConfigField("String", "AUDD_API_KEY", "\"${secret("AUDD_API_KEY")}\"")
        buildConfigField("String", "YOUTUBE_API_KEY", "\"${secret("YOUTUBE_API_KEY")}\"")
    }

    buildTypes {
        release { isMinifyEnabled = false }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { buildConfig = true }
}

dependencies {
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")
}
