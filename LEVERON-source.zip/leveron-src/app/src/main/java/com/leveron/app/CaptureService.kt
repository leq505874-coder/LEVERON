package com.leveron.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs

/** Thu âm thanh hệ thống (AudioPlaybackCapture) ~12 giây rồi gửi đi nhận diện. */
class CaptureService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val code = intent?.getIntExtra("code", 0) ?: 0
        val data = intent?.getParcelableExtra<Intent>("data")
        if (data == null) { stopSelf(); return START_NOT_STICKY }

        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("rec", "Nhận diện", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "rec")
            .setContentTitle("LEVERON đang nghe...")
            .setSmallIcon(R.drawable.ic_mic)
            .build()
        startForeground(7, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)

        RecognizeState.busy.value = true
        RecognizeState.say("Đang nghe âm thanh hệ thống…")
        val proj = getSystemService(MediaProjectionManager::class.java).getMediaProjection(code, data)
        proj.registerCallback(object : MediaProjection.Callback() {}, Handler(Looper.getMainLooper()))

        scope.launch {
            try {
                val started = SystemClock.elapsedRealtime()
                val pcm = record(proj, 12)
                if (pcm == null) {
                    RecognizeState.say("Không thu được âm thanh (app đang phát có thể chặn ghi âm)")
                    return@launch
                }
                val token = Prefs.auddKey(this@CaptureService)
                if (token.isBlank()) { RecognizeState.say("Chưa có AudD API key (Cài đặt)"); return@launch }
                RecognizeState.say("Đang nhận diện…")
                Recognizer.identify(token, pcm, started)
                    .onSuccess { t ->
                        withContext(Dispatchers.Main) { MediaHub.setRecognized(t) }
                        RecognizeState.say("Đã nhận ra: ${t.title}")
                    }
                    .onFailure { RecognizeState.say(it.message ?: "Nhận diện thất bại") }
            } catch (e: Exception) {
                RecognizeState.say("Lỗi: ${e.message}")
            } finally {
                runCatching { proj.stop() }
                RecognizeState.busy.value = false
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    @Suppress("MissingPermission")
    private fun record(proj: MediaProjection, seconds: Int): ByteArray? {
        val cfg = AudioPlaybackCaptureConfiguration.Builder(proj)
            .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
            .addMatchingUsage(AudioAttributes.USAGE_GAME)
            .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
            .build()
        val fmt = AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(Recognizer.SAMPLE_RATE)
            .setChannelMask(AudioFormat.CHANNEL_IN_MONO).build()
        val rec = AudioRecord.Builder().setAudioFormat(fmt).setAudioPlaybackCaptureConfig(cfg)
            .setBufferSizeInBytes(Recognizer.SAMPLE_RATE * 2).build()
        val total = Recognizer.SAMPLE_RATE * 2 * seconds
        val out = ByteArray(total)
        var off = 0
        rec.startRecording()
        while (off < total) {
            val n = rec.read(out, off, minOf(8192, total - off))
            if (n <= 0) break
            off += n
        }
        rec.stop(); rec.release()
        // Kiểm tra có tiếng thật hay chỉ là im lặng.
        var peak = 0
        var i = 0
        while (i + 1 < off) {
            val s = (out[i].toInt() and 0xFF) or (out[i + 1].toInt() shl 8)
            peak = maxOf(peak, abs(s.toShort().toInt()))
            i += 2
        }
        return if (off < total / 2 || peak < 200) null else out.copyOf(off)
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        fun start(ctx: Context, code: Int, data: Intent) {
            ctx.startForegroundService(Intent(ctx, CaptureService::class.java).putExtra("code", code).putExtra("data", data))
        }
    }
}
