package com.leveron.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.audiofx.AudioEffect
import android.media.audiofx.DynamicsProcessing
import android.media.audiofx.Equalizer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.sqrt

/**
 * EQ 10 band (31 Hz → 16 kHz, ±12 dB).
 * Android không cho app thường EQ "toàn hệ thống", nên EQ gắn vào audio session
 * mà app phát nhạc chia sẻ qua broadcast OPEN_AUDIO_EFFECT_CONTROL_SESSION (Spotify, YT Music, VLC...).
 * Dùng DynamicsProcessing (10 band tự do); máy không hỗ trợ thì lùi về Equalizer của hệ thống.
 */
object EqEngine {
    const val BANDS = 10
    const val MAX_DB = 12f
    val FREQS = floatArrayOf(31f, 62f, 125f, 250f, 500f, 1000f, 2000f, 4000f, 8000f, 16000f)
    val LABELS = arrayOf("31", "62", "125", "250", "500", "1k", "2k", "4k", "8k", "16k")

    val PRESETS: Map<String, FloatArray> = linkedMapOf(
        "Flat" to floatArrayOf(0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f),
        "Bass" to floatArrayOf(7f, 6f, 5f, 3f, 1f, 0f, 0f, 0f, 0f, 0f),
        "Vocal" to floatArrayOf(-2f, -2f, -1f, 1f, 3f, 4f, 4f, 2f, 0f, -1f),
        "Treble" to floatArrayOf(0f, 0f, 0f, 0f, 0f, 1f, 3f, 5f, 6f, 7f),
        "Rock" to floatArrayOf(5f, 4f, 3f, 1f, -1f, -1f, 1f, 3f, 4f, 5f),
        "Pop" to floatArrayOf(-1f, 1f, 3f, 4f, 3f, 1f, -1f, -1f, 1f, 2f),
        "EDM" to floatArrayOf(6f, 5f, 2f, 0f, -2f, 0f, 1f, 3f, 5f, 6f),
        "Acoustic" to floatArrayOf(3f, 3f, 2f, 1f, 1f, 1f, 2f, 3f, 3f, 2f),
    )

    private interface Fx { fun apply(g: FloatArray, on: Boolean); fun release() }

    private lateinit var app: Context
    private var inited = false
    var gains = FloatArray(BANDS); private set
    var enabled = true; private set
    private val sessions = HashMap<Int, Fx>()
    private val owners = HashMap<Int, String>()

    private val _status = MutableStateFlow("Chưa có app nào chia sẻ audio session cho EQ")
    val status: StateFlow<String> = _status

    @Synchronized
    fun init(c: Context) {
        if (inited) return
        app = c.applicationContext
        gains = Prefs.eqGains(app)
        enabled = Prefs.eqEnabled(app)
        inited = true
    }

    @Synchronized
    fun setBand(i: Int, db: Float) {
        gains[i] = db.coerceIn(-MAX_DB, MAX_DB)
        pushAll()
    }

    @Synchronized
    fun setAll(g: FloatArray) {
        gains = g.copyOf()
        pushAll()
        Prefs.setEqGains(app, gains)
    }

    @Synchronized
    fun commit() = Prefs.setEqGains(app, gains)

    @Synchronized
    fun setEnabled(v: Boolean) {
        enabled = v
        Prefs.setEqEnabled(app, v)
        pushAll()
    }

    private fun pushAll() {
        sessions.values.forEach { runCatching { it.apply(gains, enabled) } }
    }

    @Synchronized
    fun attach(session: Int, pkg: String?) {
        if (!inited) return
        release(session)
        val fx: Fx = try {
            DpFx(session)
        } catch (e: Throwable) {
            try { EqFx(session) } catch (e2: Throwable) {
                _status.value = "Không gắn được EQ vào session $session (${e2.javaClass.simpleName})"
                return
            }
        }
        runCatching { fx.apply(gains, enabled) }
        sessions[session] = fx
        owners[session] = pkg ?: "session $session"
        refreshStatus()
    }

    @Synchronized
    fun release(session: Int) {
        sessions.remove(session)?.release()
        owners.remove(session)
        refreshStatus()
    }

    private fun refreshStatus() {
        _status.value = if (sessions.isEmpty()) "Chưa có app nào chia sẻ audio session cho EQ"
        else "EQ đang áp lên: " + owners.values.distinct().joinToString(", ") { label(it) }
    }

    private fun label(pkg: String) = try {
        app.packageManager.getApplicationLabel(app.packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (_: Exception) { pkg }

    /** Nội suy gain theo tần số (thang log) từ 10 band. */
    private fun gainAt(freq: Float): Float {
        if (freq <= FREQS.first()) return gains.first()
        if (freq >= FREQS.last()) return gains.last()
        for (i in 0 until BANDS - 1) {
            if (freq <= FREQS[i + 1]) {
                val t = (ln(freq) - ln(FREQS[i])) / (ln(FREQS[i + 1]) - ln(FREQS[i]))
                return gains[i] + (gains[i + 1] - gains[i]) * t
            }
        }
        return 0f
    }

    private class DpFx(session: Int) : Fx {
        private val dp: DynamicsProcessing

        init {
            val cfg = DynamicsProcessing.Config.Builder(
                DynamicsProcessing.VARIANT_FAVOR_FREQUENCY_RESOLUTION,
                2, true, BANDS, false, 0, false, 0, false
            ).build()
            for (ch in 0 until 2) {
                val eq = cfg.getChannelByChannelIndex(ch).preEq
                for (i in 0 until BANDS) {
                    val cutoff = if (i < BANDS - 1) sqrt(FREQS[i] * FREQS[i + 1]) else 20000f
                    eq.getBand(i).apply { isEnabled = true; cutoffFrequency = cutoff; gain = 0f }
                }
            }
            dp = DynamicsProcessing(0, session, cfg)
        }

        override fun apply(g: FloatArray, on: Boolean) {
            for (i in 0 until BANDS) {
                dp.setPreEqBandAllChannelsTo(
                    i,
                    DynamicsProcessing.EqBand(true,
                        if (i < BANDS - 1) sqrt(FREQS[i] * FREQS[i + 1]) else 20000f,
                        if (on) g[i] else 0f)
                )
            }
            // Giảm gain đầu vào bằng mức boost lớn nhất để tránh vỡ tiếng.
            dp.setInputGainAllChannelsTo(if (on) -max(0f, g.max()) else 0f)
            dp.enabled = true
        }

        override fun release() = dp.release()
    }

    private class EqFx(session: Int) : Fx {
        private val eq = Equalizer(0, session)

        override fun apply(g: FloatArray, on: Boolean) {
            val range = eq.bandLevelRange
            for (b in 0 until eq.numberOfBands) {
                val hz = eq.getCenterFreq(b.toShort()) / 1000f
                val mb = (if (on) EqEngine.gainAt(hz) else 0f) * 100f
                eq.setBandLevel(b.toShort(), mb.toInt().coerceIn(range[0].toInt(), range[1].toInt()).toShort())
            }
            eq.enabled = true
        }

        override fun release() = eq.release()
    }
}

/** Nhận broadcast từ app phát nhạc khi mở/đóng audio session. */
class EffectSessionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        EqEngine.init(context)
        val session = intent.getIntExtra(AudioEffect.EXTRA_AUDIO_SESSION, -1)
        if (session < 0) return
        val pkg = intent.getStringExtra(AudioEffect.EXTRA_PACKAGE_NAME)
        when (intent.action) {
            AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION -> EqEngine.attach(session, pkg)
            AudioEffect.ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION -> EqEngine.release(session)
        }
    }
}
