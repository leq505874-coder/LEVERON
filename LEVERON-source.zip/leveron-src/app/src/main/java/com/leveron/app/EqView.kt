package com.leveron.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs

/** 10 thanh trượt dọc + đường cong EQ mượt, vẽ tay. */
class EqView(c: Context) : View(c) {
    var gains = FloatArray(EqEngine.BANDS)
        set(v) { field = v.copyOf(); invalidate() }
    var accent = Color.parseColor("#7C5CFF")
        set(v) { field = v; invalidate() }
    var onChange: ((band: Int, db: Float) -> Unit)? = null
    var onRelease: (() -> Unit)? = null

    private val d = resources.displayMetrics.density
    private val grid = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(40, 255, 255, 255); strokeWidth = 1f * d }
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(50, 255, 255, 255); strokeWidth = 4f * d; strokeCap = Paint.Cap.ROUND }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeWidth = 4f * d; strokeCap = Paint.Cap.ROUND }
    private val knob = Paint(Paint.ANTI_ALIAS_FLAG)
    private val curve = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2.5f * d }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(170, 255, 255, 255); textSize = 10f * d; textAlign = Paint.Align.CENTER }
    private val textL = Paint(text).apply { textAlign = Paint.Align.LEFT }

    private var active = -1
    private val topPad = 14f * d
    private val botPad = 26f * d

    private fun colW() = width.toFloat() / EqEngine.BANDS
    private fun cx(i: Int) = colW() * (i + 0.5f)
    private fun yOf(db: Float): Float {
        val h = height - topPad - botPad
        return topPad + h * (1f - (db + EqEngine.MAX_DB) / (2 * EqEngine.MAX_DB))
    }
    private fun dbOf(y: Float): Float {
        val h = height - topPad - botPad
        val t = 1f - ((y - topPad) / h).coerceIn(0f, 1f)
        val v = t * 2 * EqEngine.MAX_DB - EqEngine.MAX_DB
        // Hít về 0 dB và làm tròn 0.5 dB.
        val r = Math.round(v * 2f) / 2f
        return if (abs(r) < 0.4f) 0f else r
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        // Đường lưới: +12, 0, -12
        for (db in floatArrayOf(EqEngine.MAX_DB, 0f, -EqEngine.MAX_DB)) {
            val y = yOf(db)
            cv.drawLine(0f, y, w, y, grid)
        }
        cv.drawText("+12", 2f * d, yOf(EqEngine.MAX_DB) + 11f * d, textL)
        cv.drawText("0", 2f * d, yOf(0f) - 3f * d, textL)
        cv.drawText("-12", 2f * d, yOf(-EqEngine.MAX_DB) - 3f * d, textL)

        // Đường cong mượt (Catmull-Rom → Bezier) + vùng tô.
        val pts = Array(EqEngine.BANDS) { floatArrayOf(cx(it), yOf(gains[it])) }
        val path = Path()
        path.moveTo(pts[0][0], pts[0][1])
        for (i in 0 until pts.size - 1) {
            val p0 = pts[maxOf(i - 1, 0)]; val p1 = pts[i]; val p2 = pts[i + 1]; val p3 = pts[minOf(i + 2, pts.size - 1)]
            path.cubicTo(
                p1[0] + (p2[0] - p0[0]) / 6f, p1[1] + (p2[1] - p0[1]) / 6f,
                p2[0] - (p3[0] - p1[0]) / 6f, p2[1] - (p3[1] - p1[1]) / 6f,
                p2[0], p2[1]
            )
        }
        val area = Path(path).apply {
            lineTo(pts.last()[0], yOf(0f)); lineTo(pts[0][0], yOf(0f)); close()
        }
        glow.color = Color.argb(60, Color.red(accent), Color.green(accent), Color.blue(accent))
        cv.drawPath(area, glow)

        val zero = yOf(0f)
        for (i in 0 until EqEngine.BANDS) {
            val x = cx(i); val y = yOf(gains[i])
            cv.drawLine(x, topPad, x, height - botPad, track)
            fill.color = accent
            cv.drawLine(x, zero, x, y, fill)
        }
        curve.color = Color.WHITE
        cv.drawPath(path, curve)
        for (i in 0 until EqEngine.BANDS) {
            val x = cx(i); val y = yOf(gains[i])
            knob.color = if (i == active) Color.WHITE else accent
            cv.drawCircle(x, y, (if (i == active) 9f else 7f) * d, knob)
            knob.color = Color.WHITE
            cv.drawCircle(x, y, 3f * d, knob)
            cv.drawText(EqEngine.LABELS[i], x, height - 8f * d, text)
        }
        if (active >= 0) {
            val g = gains[active]
            val s = (if (g > 0) "+" else "") + (if (g % 1f == 0f) g.toInt().toString() else g.toString()) + " dB"
            cv.drawText(s, cx(active), maxOf(yOf(g) - 14f * d, 10f * d), Paint(text).apply { color = Color.WHITE; isFakeBoldText = true })
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                active = (e.x / colW()).toInt().coerceIn(0, EqEngine.BANDS - 1)
                update(e.y)
            }
            MotionEvent.ACTION_MOVE -> if (active >= 0) update(e.y)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                active = -1
                invalidate()
                onRelease?.invoke()
            }
        }
        return true
    }

    private fun update(y: Float) {
        val db = dbOf(y)
        if (gains[active] != db) {
            gains[active] = db
            onChange?.invoke(active, db)
        }
        invalidate()
    }
}
