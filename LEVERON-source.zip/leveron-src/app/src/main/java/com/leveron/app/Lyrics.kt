package com.leveron.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs

/** Lời bài hát (có thể đồng bộ theo thời gian) lấy từ LRCLIB — miễn phí, không cần key. */
class Lyrics(val synced: List<Pair<Long, String>>, val plain: String) {
    val isEmpty get() = synced.isEmpty() && plain.isBlank()

    /** Chỉ số dòng đang hát tại [posMs], -1 nếu chưa đến dòng đầu. */
    fun indexAt(posMs: Long): Int {
        var lo = 0; var hi = synced.size - 1; var ans = -1
        while (lo <= hi) {
            val mid = (lo + hi) / 2
            if (synced[mid].first <= posMs) { ans = mid; lo = mid + 1 } else hi = mid - 1
        }
        return ans
    }

    companion object {
        private val http = OkHttpClient()
        private val cache = HashMap<String, Lyrics>()
        private val STAMP = Regex("\\[(\\d+):(\\d+(?:[.:]\\d+)?)]")

        fun parseLrc(lrc: String): List<Pair<Long, String>> {
            val out = ArrayList<Pair<Long, String>>()
            for (line in lrc.lines()) {
                val stamps = STAMP.findAll(line).toList()
                if (stamps.isEmpty()) continue
                val text = line.substring(stamps.last().range.last + 1).trim()
                for (m in stamps) {
                    val min = m.groupValues[1].toLong()
                    val sec = m.groupValues[2].replace(':', '.').toDouble()
                    out.add(((min * 60 + sec) * 1000).toLong() to text)
                }
            }
            return out.sortedBy { it.first }
        }

        private fun get(url: okhttp3.HttpUrl): String? =
            http.newCall(Request.Builder().url(url).header("User-Agent", "LEVERON/2.0").build()).execute().use {
                if (it.isSuccessful) it.body?.string() else null
            }

        private fun from(o: JSONObject) = Lyrics(
            parseLrc(o.optString("syncedLyrics", "")),
            o.optString("plainLyrics", "")
        )

        suspend fun fetch(artist: String, title: String, durationMs: Long): Lyrics? {
            val key = "$artist|$title"
            cache[key]?.let { return it }
            val res = withContext(Dispatchers.IO) {
                runCatching {
                    val firstArtist = artist.split(',', '&', ';').firstOrNull()?.trim().orEmpty()
                    val cleanTitle = title.replace(Regex("[\\(\\[].*?[\\)\\]]"), "").trim().ifBlank { title }
                    // 1) khớp chính xác kèm độ dài
                    if (durationMs > 0) {
                        val u = "https://lrclib.net/api/get".toHttpUrl().newBuilder()
                            .addQueryParameter("track_name", cleanTitle)
                            .addQueryParameter("artist_name", firstArtist)
                            .addQueryParameter("duration", (durationMs / 1000).toString()).build()
                        get(u)?.let { val l = from(JSONObject(it)); if (!l.isEmpty) return@runCatching l }
                    }
                    // 2) tìm kiếm, chọn kết quả có lời đồng bộ và độ dài gần nhất
                    val u = "https://lrclib.net/api/search".toHttpUrl().newBuilder()
                        .addQueryParameter("track_name", cleanTitle)
                        .addQueryParameter("artist_name", firstArtist).build()
                    val arr = get(u)?.let { JSONArray(it) } ?: return@runCatching null
                    var best: JSONObject? = null; var bestScore = Long.MAX_VALUE
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        if (o.optString("syncedLyrics").isBlank() && o.optString("plainLyrics").isBlank()) continue
                        val diff = if (durationMs > 0) abs(o.optDouble("duration", 0.0) * 1000 - durationMs).toLong() else 0L
                        val score = diff + if (o.optString("syncedLyrics").isBlank()) 20_000 else 0
                        if (score < bestScore) { bestScore = score; best = o }
                    }
                    best?.let { from(it) }
                }.getOrNull()
            }
            if (res != null && !res.isEmpty) cache[key] = res
            return res
        }
    }
}
