package com.leveron.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs

/** Lời bài hát (có thể đồng bộ theo thời gian) lấy từ LRCLIB — miễn phí, không cần key. */
class Lyrics(val synced: List<Pair<Long, String>>, val plain: String) {
    val isEmpty get() = synced.isEmpty() && plain.isBlank()

    /** Chỉ số dòng đang hát tại [posMs], -1 nếu chưa đến dòng đầu. */
    fun indexAt(posMs: Long): Int {
        var lo = 0; var hi = synced.size - 1; var ans = -1
        while (lo <= hi) {
            val mid = (lo + hi) / 2
            if (synced[mid].first <= posMs) { ans = mid; lo = mid + 1 } else hi = mid - 1
        }
        return ans
    }

    companion object {
        private val http = OkHttpClient()
        private val cache = HashMap<String, Lyrics>()
        private val STAMP = Regex("\\[(\\d+):(\\d+(?:[.:]\\d+)?)]")

        fun parseLrc(lrc: String): List<Pair<Long, String>> {
            val out = ArrayList<Pair<Long, String>>()
            for (line in lrc.lines()) {
                val stamps = STAMP.findAll(line).toList()
                if (stamps.isEmpty()) continue
                val text = line.substring(stamps.last().range.last + 1).trim()
                for (m in stamps) {
                    val min = m.groupValues[1].toLong()
                    val sec = m.groupValues[2].replace(':', '.').toDouble()
                    out.add(((min * 60 + sec) * 1000).toLong() to text)
                }
            }
            return out.sortedBy { it.first }
        }

        private fun get(url: okhttp3.HttpUrl): String? =
            http.newCall(Request.Builder().url(url).header("User-Agent", "LEVERON/2.0").build()).execute().use {
                if (it.isSuccessful) it.body?.string() else null
            }

        private fun from(o: JSONObject) = Lyrics(
            parseLrc(o.optString("syncedLyrics", "")),
            o.optString("plainLyrics", "")
        )

        private fun norm(s: String): String =
            java.text.Normalizer.normalize(s.lowercase().replace('đ', 'd'), java.text.Normalizer.Form.NFD)
                .replace(Regex("\\p{M}+"), "").replace(Regex("[^a-z0-9]+"), "")

        /** Bỏ phần phụ trong tên bài: (Official...), [Beat], - Remastered, feat. ... */
        fun clean(t: String): String = t
            .replace(Regex("[\\(\\[].*?[\\)\\]]"), "")
            .replace(Regex("(?i)\\s*[-–|]\\s*(remaster(ed)?|single|live|ost|official|lyrics?|audio|mv|beat|version).*$"), "")
            .replace(Regex("(?i)\\s+(feat|ft)\\.?\\s.*$"), "")
            .trim()

        private fun titleOk(o: JSONObject, song: String): Boolean {
            val tn = norm(o.optString("trackName", o.optString("name")))
            return tn.length >= 2 && song.length >= 2 && (tn.contains(song) || song.contains(tn))
        }

        private fun search(params: Map<String, String>): List<JSONObject> {
            val b = "https://lrclib.net/api/search".toHttpUrl().newBuilder()
            params.forEach { (k, v) -> b.addQueryParameter(k, v) }
            val arr = get(b.build())?.let { JSONArray(it) } ?: return emptyList()
            return List(arr.length()) { arr.getJSONObject(it) }
        }

        /** Tìm lời: nhiều biến thể truy vấn → chọn kết quả đúng tên bài, có mốc thời gian, độ dài gần nhất. */
        suspend fun fetch(artist: String, title: String, durationMs: Long): Lyrics? {
            val key = "$artist|$title"
            cache[key]?.let { return it }
            val res = withContext(Dispatchers.IO) {
                runCatching {
                    val artists = artist.split(',', '&', ';', '/').map { it.trim() }.filter { it.isNotEmpty() }
                    val first = artists.firstOrNull().orEmpty()
                    val ct = clean(title).ifBlank { title }
                    val song = norm(ct)

                    // 1) khớp chính xác (kèm độ dài)
                    if (durationMs > 0 && first.isNotEmpty()) {
                        val u = "https://lrclib.net/api/get".toHttpUrl().newBuilder()
                            .addQueryParameter("track_name", ct)
                            .addQueryParameter("artist_name", first)
                            .addQueryParameter("duration", (durationMs / 1000).toString()).build()
                        runCatching { get(u)?.let { from(JSONObject(it)) } }.getOrNull()?.let { if (!it.isEmpty) return@runCatching it }
                    }

                    // 2) các biến thể tìm kiếm, dừng ở biến thể đầu tiên cho kết quả đúng bài
                    val variants = ArrayList<Map<String, String>>()
                    if (first.isNotEmpty()) variants += mapOf("track_name" to ct, "artist_name" to first)
                    artists.drop(1).take(3).forEach { variants += mapOf("track_name" to ct, "artist_name" to it) }
                    variants += mapOf("q" to "$first $ct".trim())
                    variants += mapOf("q" to ct)
                    if (ct != title) variants += mapOf("q" to title)

                    for (v in variants) {
                        val list = runCatching { search(v) }.getOrDefault(emptyList()).filter {
                            titleOk(it, song) && (it.optString("syncedLyrics").isNotBlank() || it.optString("plainLyrics").isNotBlank())
                        }
                        if (list.isEmpty()) continue
                        fun score(o: JSONObject): Long {
                            val dur = o.optDouble("duration", 0.0) * 1000
                            val diff = if (durationMs > 0 && dur > 0) abs(dur - durationMs).toLong() else 0L
                            val ar = norm(o.optString("artistName"))
                            val artistBonus = if (artists.any { norm(it).let { n -> n.length >= 2 && (ar.contains(n) || n.contains(ar)) } }) 0L else 8_000L
                            return diff + artistBonus + if (o.optString("syncedLyrics").isBlank()) 20_000L else 0L
                        }
                        val best = list.minByOrNull { score(it) }!!
                        // Nếu độ dài lệch quá 30 giây thì có thể là bản khác → thử biến thể tiếp theo.
                        if (durationMs > 0 && best.optDouble("duration", 0.0) > 0 &&
                            abs(best.optDouble("duration") * 1000 - durationMs) > 30_000 && v !== variants.last()) continue
                        return@runCatching from(best)
                    }

                    // 3) dự phòng: lyrics.ovh (chỉ có lời thường, không có mốc thời gian)
                    if (first.isNotEmpty()) {
                        val u = "https://api.lyrics.ovh/v1".toHttpUrl().newBuilder()
                            .addPathSegment(first).addPathSegment(ct).build()
                        val txt = get(u)?.let { JSONObject(it).optString("lyrics") }.orEmpty()
                        if (txt.isNotBlank()) return@runCatching Lyrics(emptyList(), txt.trim())
                    }
                    null
                }.getOrNull()
            }
            if (res != null && !res.isEmpty) cache[key] = res
            return res
        }
    }
}
