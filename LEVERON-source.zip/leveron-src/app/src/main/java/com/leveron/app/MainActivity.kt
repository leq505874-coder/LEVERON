package com.leveron.app

import android.Manifest
import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Outline
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import android.content.res.ColorStateList
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs

/** Toàn bộ UI dựng bằng code để không phụ thuộc thư viện ngoài. */
class MainActivity : Activity() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val d by lazy { resources.displayMetrics.density }
    private fun dp(v: Int) = (v * d).toInt()

    private val defaultAccent = Color.parseColor("#7C5CFF")
    private var accent = defaultAccent
    private var themeAnim: ValueAnimator? = null
    private var themedFor: Bitmap? = null

    // Views
    private lateinit var bg: View
    private lateinit var permCard: LinearLayout
    private lateinit var stage: FrameLayout
    private lateinit var artView: ImageView
    private lateinit var video: VideoPlayerView
    private lateinit var tvTitle: TextView
    private lateinit var tvArtist: TextView
    private lateinit var tvSource: TextView
    private lateinit var seek: SeekBar
    private lateinit var tvPos: TextView
    private lateinit var tvDur: TextView
    private lateinit var btnPlay: ImageButton
    private lateinit var btnPrev: ImageButton
    private lateinit var btnNext: ImageButton
    private lateinit var btnMic: ImageButton
    private lateinit var tvRec: TextView
    private lateinit var swVideo: Switch
    private lateinit var tvOffset: TextView
    private lateinit var videoRow: LinearLayout
    private lateinit var eqView: EqView
    private lateinit var swEq: Switch
    private lateinit var tvEqStatus: TextView
    private val chips = LinkedHashMap<String, TextView>()
    private val cards = ArrayList<View>()

    // State
    private var track = Track()
    private var dragging = false
    private var videoKey = ""
    private var videoIds: List<String> = emptyList()
    private var videoIdx = 0
    private var videoLive = false
    private var videoJob: Job? = null
    private var lastSyncPos = 0L
    private var lastSyncAt = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        EqEngine.init(this)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        buildUi()

        scope.launch { MediaHub.track.collect { onTrack(it) } }
        scope.launch { EqEngine.status.collect { tvEqStatus.text = it } }
        scope.launch { RecognizeState.status.collect { tvRec.text = it; tvRec.visibility = if (it.isBlank()) View.GONE else View.VISIBLE } }
        scope.launch { RecognizeState.busy.collect { btnMic.alpha = if (it) 0.4f else 1f; btnMic.isEnabled = !it } }
        scope.launch { tickLoop() }
    }

    override fun onResume() {
        super.onResume()
        val ok = MediaHub.start(this) && notificationAccessGranted()
        permCard.visibility = if (ok) View.GONE else View.VISIBLE
    }

    override fun onDestroy() {
        scope.cancel()
        video.release()
        super.onDestroy()
    }

    // ------------------------------------------------------------------ UI

    private fun buildUi() {
        val root = FrameLayout(this)
        bg = View(this)
        root.addView(bg, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)

        val scroll = ScrollView(this).apply { isVerticalScrollBarEnabled = false; overScrollMode = View.OVER_SCROLL_NEVER }
        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), 0, dp(20), dp(40)) }
        scroll.addView(page)
        root.addView(scroll, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        @Suppress("DEPRECATION")
        root.setOnApplyWindowInsetsListener { _, ins ->
            scroll.setPadding(0, ins.systemWindowInsetTop, 0, ins.systemWindowInsetBottom)
            ins
        }

        // Header
        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(14), 0, dp(14)) }
        header.addView(TextView(this).apply {
            text = "LEVERON"; setTextColor(Color.WHITE); textSize = 18f; letterSpacing = 0.3f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(TextView(this).apply {
            text = "Cài đặt"; setTextColor(Color.argb(200, 255, 255, 255)); textSize = 13f
            background = rounded(Color.argb(40, 255, 255, 255), 16)
            setPadding(dp(14), dp(7), dp(14), dp(7))
            setOnClickListener { showSettings() }
        })
        page.addView(header)

        // Thẻ xin quyền
        permCard = card().apply {
            addView(label("Cho phép LEVERON đọc trạng thái phát nhạc", 15f, true))
            addView(label("Bật “Truy cập thông báo” cho LEVERON để biết bài đang phát, tua, phát/dừng. Ứng dụng không đọc nội dung thông báo.", 12.5f, false).apply { setPadding(0, dp(6), 0, dp(10)) })
            addView(pill("Mở cài đặt quyền") { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) })
        }
        page.addView(permCard, lp(bottom = 16))

        // Sân khấu: ảnh bìa hoặc video
        stage = FrameLayout(this).apply {
            clipToOutline = true
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(v: View, o: Outline) = o.setRoundRect(0, 0, v.width, v.height, dp(24).toFloat())
            }
            setBackgroundColor(Color.argb(50, 255, 255, 255))
        }
        artView = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        video = VideoPlayerView(this).apply { visibility = View.INVISIBLE }
        stage.addView(artView, FrameLayout.LayoutParams(-1, -1))
        stage.addView(video, FrameLayout.LayoutParams(-1, -1))
        page.addView(stage, LinearLayout.LayoutParams(-1, stageHeight(false)))
        video.onPlaying = { if (videoIds.isNotEmpty()) showVideo(true) }
        video.onError = { videoIdx++; startVideo() }

        // Thông tin bài
        tvTitle = label("Chưa có bài hát", 24f, true).apply { setPadding(0, dp(18), 0, 0); maxLines = 2 }
        tvArtist = label("Mở Spotify, YouTube Music… rồi phát nhạc", 15f, false).apply { setTextColor(Color.argb(190, 255, 255, 255)) }
        tvSource = label("", 12f, false).apply { setTextColor(Color.argb(130, 255, 255, 255)); setPadding(0, dp(4), 0, 0) }
        page.addView(tvTitle); page.addView(tvArtist); page.addView(tvSource)

        // Thanh tua
        seek = SeekBar(this).apply {
            max = 1000
            setPadding(dp(0), dp(14), dp(0), dp(4))
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                    if (fromUser && track.durationMs > 0) tvPos.text = fmt(track.durationMs * p / 1000)
                }
                override fun onStartTrackingTouch(s: SeekBar) { dragging = true }
                override fun onStopTrackingTouch(s: SeekBar) {
                    dragging = false
                    if (track.controllable && track.canSeek && track.durationMs > 0) {
                        val ms = track.durationMs * s.progress / 1000
                        MediaHub.seekTo(ms)
                        // Cập nhật ngay để video nhảy theo.
                        track = track.copy(positionMs = ms, stamp = android.os.SystemClock.elapsedRealtime())
                        syncVideo(true)
                    }
                }
            })
        }
        page.addView(seek, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))
        val times = LinearLayout(this)
        tvPos = label("0:00", 11.5f, false).apply { setTextColor(Color.argb(160, 255, 255, 255)) }
        tvDur = label("0:00", 11.5f, false).apply { setTextColor(Color.argb(160, 255, 255, 255)); gravity = Gravity.END }
        times.addView(tvPos, LinearLayout.LayoutParams(0, -2, 1f)); times.addView(tvDur, LinearLayout.LayoutParams(0, -2, 1f))
        page.addView(times)

        // Nút điều khiển
        val ctrl = LinearLayout(this).apply { gravity = Gravity.CENTER; setPadding(0, dp(10), 0, dp(6)) }
        btnPrev = iconBtn(R.drawable.ic_prev, 56) { MediaHub.prev() }
        btnPlay = iconBtn(R.drawable.ic_play, 76) { MediaHub.toggle() }
        btnNext = iconBtn(R.drawable.ic_next, 56) { MediaHub.next() }
        btnMic = iconBtn(R.drawable.ic_mic, 56) { onRecognize() }
        ctrl.addView(btnMic, LinearLayout.LayoutParams(dp(56), dp(56)).apply { rightMargin = dp(14) })
        ctrl.addView(btnPrev, LinearLayout.LayoutParams(dp(56), dp(56)))
        ctrl.addView(btnPlay, LinearLayout.LayoutParams(dp(76), dp(76)).apply { leftMargin = dp(10); rightMargin = dp(10) })
        ctrl.addView(btnNext, LinearLayout.LayoutParams(dp(56), dp(56)))
        ctrl.addView(View(this), LinearLayout.LayoutParams(dp(56), dp(56)).apply { leftMargin = dp(14) })
        page.addView(ctrl)
        tvRec = label("", 12.5f, false).apply { gravity = Gravity.CENTER; visibility = View.GONE; setTextColor(Color.argb(200, 255, 255, 255)) }
        page.addView(tvRec)

        // Hàng cài đặt video
        videoRow = card().apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            swVideo = Switch(this@MainActivity).apply {
                isChecked = Prefs.showVideo(this@MainActivity)
                setOnCheckedChangeListener { _, on ->
                    Prefs.setShowVideo(this@MainActivity, on)
                    videoKey = ""; onTrack(track)
                }
            }
            addView(label("Video", 14f, true), LinearLayout.LayoutParams(0, -2, 1f))
            addView(smallBtn("⟳") { nextVideo() }, LinearLayout.LayoutParams(dp(36), dp(36)).apply { rightMargin = dp(8) })
            addView(smallBtn("−") { nudge(-250) })
            tvOffset = label("", 12.5f, false).apply { gravity = Gravity.CENTER }
            addView(tvOffset, LinearLayout.LayoutParams(dp(78), -2))
            addView(smallBtn("+") { nudge(250) })
            addView(swVideo, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(14) })
        }
        updateOffsetLabel()
        page.addView(videoRow, lp(top = 14))

        // Thẻ EQ
        val eqCard = card().apply {
            val head = LinearLayout(this@MainActivity).apply { gravity = Gravity.CENTER_VERTICAL }
            head.addView(label("Equalizer", 17f, true), LinearLayout.LayoutParams(0, -2, 1f))
            swEq = Switch(this@MainActivity).apply {
                isChecked = EqEngine.enabled
                setOnCheckedChangeListener { _, on -> EqEngine.setEnabled(on); eqView.alpha = if (on) 1f else 0.4f }
            }
            head.addView(swEq)
            addView(head)
            tvEqStatus = label("", 11.5f, false).apply { setTextColor(Color.argb(150, 255, 255, 255)); setPadding(0, dp(4), 0, dp(8)) }
            addView(tvEqStatus)
            eqView = EqView(this@MainActivity).apply {
                gains = EqEngine.gains
                alpha = if (EqEngine.enabled) 1f else 0.4f
                onChange = { i, db -> EqEngine.setBand(i, db); markCustomIfNeeded() }
                onRelease = { EqEngine.commit(); markCustomIfNeeded(true) }
            }
            addView(eqView, LinearLayout.LayoutParams(-1, dp(230)))
            val hs = HorizontalScrollView(this@MainActivity).apply { isHorizontalScrollBarEnabled = false }
            val row = LinearLayout(this@MainActivity).apply { setPadding(0, dp(12), 0, 0) }
            for (name in EqEngine.PRESETS.keys) {
                val chip = TextView(this@MainActivity).apply {
                    text = name; textSize = 13f; setTextColor(Color.WHITE)
                    setPadding(dp(16), dp(8), dp(16), dp(8))
                    setOnClickListener { applyPreset(name) }
                }
                chips[name] = chip
                row.addView(chip, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(8) })
            }
            hs.addView(row)
            addView(hs)
        }
        page.addView(eqCard, lp(top = 14))
        page.addView(label(
            "EQ chỉ áp được lên app phát nhạc có chia sẻ audio session (Spotify, YouTube Music, VLC…). Android không cho app thường chỉnh EQ toàn hệ thống.",
            11f, false
        ).apply { setTextColor(Color.argb(110, 255, 255, 255)); setPadding(dp(4), dp(10), dp(4), 0) })

        setContentView(root)
        markCustomIfNeeded(true)
        applyTheme(defaultAccent)
        layoutStage(false)
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(16), dp(16), dp(16))
        cards.add(this)
        background = rounded(Color.argb(28, 255, 255, 255), 24)
    }

    private fun lp(top: Int = 0, bottom: Int = 0) =
        LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(top); bottomMargin = dp(bottom) }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }

    private fun label(t: String, size: Float, bold: Boolean) = TextView(this).apply {
        text = t; textSize = size; setTextColor(Color.WHITE)
        if (bold) typeface = android.graphics.Typeface.DEFAULT_BOLD
    }

    private fun pill(t: String, onClick: () -> Unit) = TextView(this).apply {
        text = t; setTextColor(Color.WHITE); textSize = 14f; gravity = Gravity.CENTER
        setPadding(dp(18), dp(11), dp(18), dp(11))
        tag = "accentBg"
        background = rounded(accent, 24)
        setOnClickListener { onClick() }
        accentViews.add(this)
    }

    private val accentViews = ArrayList<TextView>()

    private fun smallBtn(t: String, onClick: () -> Unit) = TextView(this).apply {
        text = t; setTextColor(Color.WHITE); textSize = 18f; gravity = Gravity.CENTER
        background = rounded(Color.argb(40, 255, 255, 255), 18)
        layoutParams = LinearLayout.LayoutParams(dp(36), dp(36))
        setOnClickListener { onClick() }
    }

    private fun iconBtn(res: Int, size: Int, onClick: () -> Unit) = ImageButton(this).apply {
        setImageResource(res)
        scaleType = ImageView.ScaleType.CENTER
        setPadding(0, 0, 0, 0)
        background = rounded(if (size > 60) accent else Color.argb(36, 255, 255, 255), size / 2)
        setOnClickListener { onClick() }
        tag = if (size > 60) "accent" else null
    }

    // ------------------------------------------------------------ Theme

    private fun applyTheme(c: Int) {
        accent = c
        val hsv = FloatArray(3)
        Color.colorToHSV(c, hsv)
        val top = Color.HSVToColor(floatArrayOf(hsv[0], minOf(hsv[1], 0.85f), 0.42f))
        val mid = Color.HSVToColor(floatArrayOf(hsv[0], minOf(hsv[1], 0.8f), 0.17f))
        bg.background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(top, mid, Color.parseColor("#07070B")))
        (btnPlay.background as GradientDrawable).setColor(c)
        accentViews.forEach { (it.background as GradientDrawable).setColor(c) }
        seek.progressTintList = ColorStateList.valueOf(c)
        seek.thumbTintList = ColorStateList.valueOf(Color.WHITE)
        seek.progressBackgroundTintList = ColorStateList.valueOf(Color.argb(60, 255, 255, 255))
        eqView.accent = c
        swEq.trackTintList = ColorStateList.valueOf(Color.argb(120, Color.red(c), Color.green(c), Color.blue(c)))
        swVideo.trackTintList = swEq.trackTintList
        refreshChips()
    }

    private fun animateTheme(to: Int) {
        themeAnim?.cancel()
        val from = accent
        themeAnim = ValueAnimator.ofObject(ArgbEvaluator(), from, to).apply {
            duration = 700
            addUpdateListener { applyTheme(it.animatedValue as Int) }
            start()
        }
    }

    /** Màu chủ đạo của ảnh bìa: bucket theo hue, ưu tiên vùng bão hòa cao. */
    private fun dominant(b: Bitmap): Int {
        val s = Bitmap.createScaledBitmap(b, 32, 32, true)
        val px = IntArray(32 * 32); s.getPixels(px, 0, 32, 0, 0, 32, 32)
        val w = FloatArray(12); val r = FloatArray(12); val g = FloatArray(12); val bl = FloatArray(12)
        val hsv = FloatArray(3)
        for (p in px) {
            Color.colorToHSV(p, hsv)
            if (hsv[2] < 0.15f) continue
            val wt = hsv[1] * hsv[1] * (0.3f + hsv[2])
            val k = (hsv[0] / 30f).toInt().coerceIn(0, 11)
            w[k] += wt; r[k] += Color.red(p) * wt; g[k] += Color.green(p) * wt; bl[k] += Color.blue(p) * wt
        }
        val best = w.indices.maxByOrNull { w[it] } ?: 0
        if (w[best] < 0.3f) return Color.parseColor("#8B8FA8")
        val c = Color.rgb((r[best] / w[best]).toInt(), (g[best] / w[best]).toInt(), (bl[best] / w[best]).toInt())
        Color.colorToHSV(c, hsv)
        hsv[1] = hsv[1].coerceIn(0.45f, 0.9f)
        hsv[2] = hsv[2].coerceIn(0.65f, 0.95f)
        return Color.HSVToColor(hsv)
    }

    // ------------------------------------------------------------ Track

    private fun onTrack(t: Track) {
        val prev = track
        track = t
        tvTitle.text = if (t.hasTrack) t.title else "Chưa có bài hát"
        tvArtist.text = if (t.hasTrack) t.artist.ifBlank { "—" } else "Mở Spotify, YouTube Music… rồi phát nhạc"
        tvSource.text = when {
            !t.hasTrack -> ""
            t.recognized -> "Nhận diện từ âm thanh hệ thống · chỉ xem (không điều khiển được)"
            else -> t.appLabel + if (t.album.isNotBlank()) " · ${t.album}" else ""
        }
        btnPlay.setImageResource(if (t.playing) R.drawable.ic_pause else R.drawable.ic_play)
        val can = t.controllable
        for (b in listOf(btnPlay, btnPrev, btnNext)) { b.isEnabled = can; b.alpha = if (can) 1f else 0.35f }
        seek.isEnabled = can && t.canSeek && t.durationMs > 0
        tvDur.text = if (t.durationMs > 0) fmt(t.durationMs) else "--:--"

        if (t.art !== artView.tag) {
            artView.tag = t.art
            artView.setImageBitmap(t.art)
        }
        if (t.art !== themedFor) {
            themedFor = t.art
            val art = t.art
            if (art == null) animateTheme(defaultAccent)
            else scope.launch {
                val c = withContext(Dispatchers.Default) { dominant(art) }
                if (themedFor === art) animateTheme(c)
            }
        }

        // Video
        val wantVideo = Prefs.showVideo(this) && Prefs.youtubeKey(this).isNotBlank() && t.hasTrack
        videoRow.visibility = View.VISIBLE
        if (!wantVideo) {
            if (videoLive || videoIds.isNotEmpty()) { videoIds = emptyList(); video.stop(); showVideo(false) }
            videoKey = ""
        } else if (t.key != videoKey) {
            videoKey = t.key
            videoIds = emptyList(); videoIdx = 0
            showVideo(false); video.stop()
            videoJob?.cancel()
            videoJob = scope.launch {
                val ids = VideoResolver.find(Prefs.youtubeKey(this@MainActivity), t.artist, t.title, t.durationMs)
                if (videoKey == t.key) {
                    val pick = Prefs.pick(this@MainActivity, t.key)
                    videoIds = if (pick.isNotEmpty()) listOf(pick) + ids.filter { it != pick } else ids
                    videoIdx = 0; updateOffsetLabel(); startVideo()
                }
            }
        } else if (prev.playing != t.playing || abs(prev.position() - t.position()) > 1500) {
            syncVideo(false)
        }
    }

    private fun startVideo() {
        val id = videoIds.getOrNull(videoIdx)
        if (id == null) { showVideo(false); return }
        val t = track
        video.load(id, (t.position() + curOffset()).coerceAtLeast(0), t.playing)
    }

    private fun syncVideo(force: Boolean) {
        if (!videoLive) return
        val t = track
        video.sync((t.position() + curOffset()).coerceAtLeast(0), t.playing, force)
    }

    private fun showVideo(show: Boolean) {
        videoLive = show
        video.visibility = if (show) View.VISIBLE else View.INVISIBLE
        layoutStage(show)
    }

    private fun stageHeight(video: Boolean): Int {
        val w = resources.displayMetrics.widthPixels - dp(40)
        return if (video) w * 9 / 16 else w
    }

    private fun layoutStage(video: Boolean) {
        val p = stage.layoutParams ?: return
        val h = stageHeight(video)
        if (p.height != h) { p.height = h; stage.layoutParams = p }
    }

    private fun curId() = videoIds.getOrNull(videoIdx).orEmpty()
    private fun curOffset() = if (curId().isEmpty()) 0 else Prefs.videoOffset(this, curId())

    /** Video không đúng → thử video khác trong danh sách, và nhớ lựa chọn cho bài này. */
    private fun nextVideo() {
        if (videoIds.size < 2) { Toast.makeText(this, "Không còn video nào khác", Toast.LENGTH_SHORT).show(); return }
        videoIdx = (videoIdx + 1) % videoIds.size
        Prefs.setPick(this, videoKey, curId())
        showVideo(false); startVideo(); updateOffsetLabel()
    }

    private fun nudge(ms: Int) {
        if (curId().isEmpty()) return
        Prefs.setVideoOffset(this, curId(), curOffset() + ms)
        updateOffsetLabel(); syncVideo(true)
    }

    private fun updateOffsetLabel() {
        val o = curOffset() / 1000f
        tvOffset.text = "Lệch " + (if (o > 0) "+" else "") + o + "s"
    }

    private suspend fun tickLoop() {
        while (true) {
            val t = track
            val now = android.os.SystemClock.elapsedRealtime()
            val pos = t.position(now)
            if (!dragging) {
                tvPos.text = fmt(pos)
                seek.progress = if (t.durationMs > 0) (pos * 1000 / t.durationMs).toInt() else 0
            }
            // Phát hiện tua: vị trí nhảy so với dự đoán → ép video nhảy theo.
            val expected = lastSyncPos + if (t.playing) (now - lastSyncAt) else 0
            if (t.recognized && t.durationMs > 0 && pos >= t.durationMs) MediaHub.setRecognized(null)
            val jumped = abs(pos - expected) > 1500
            if (videoLive) syncVideo(jumped)
            lastSyncPos = pos; lastSyncAt = now
            delay(1000)
        }
    }

    private fun fmt(ms: Long): String {
        val s = ms / 1000
        return "%d:%02d".format(s / 60, s % 60)
    }

    // ------------------------------------------------------------ EQ

    private fun applyPreset(name: String) {
        val g = EqEngine.PRESETS[name] ?: return
        EqEngine.setAll(g)
        eqView.gains = g
        Prefs.setEqPreset(this, name)
        refreshChips()
    }

    private fun markCustomIfNeeded(final: Boolean = false) {
        val cur = EqEngine.PRESETS.entries.firstOrNull { it.value.contentEquals(EqEngine.gains) }?.key
        Prefs.setEqPreset(this, cur ?: "")
        if (final || cur == null) refreshChips()
    }

    private fun refreshChips() {
        val sel = Prefs.eqPreset(this)
        for ((name, v) in chips) {
            v.background = rounded(if (name == sel) accent else Color.argb(36, 255, 255, 255), 20)
        }
    }

    // ------------------------------------------------------------ Quyền & nhận diện

    private fun notificationAccessGranted(): Boolean =
        Settings.Secure.getString(contentResolver, "enabled_notification_listeners")?.contains(packageName) == true

    private fun onRecognize() {
        if (Prefs.auddKey(this).isBlank()) {
            Toast.makeText(this, "Nhập AudD API key trước", Toast.LENGTH_SHORT).show()
            showSettings(); return
        }
        val need = ArrayList<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) need += Manifest.permission.RECORD_AUDIO
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) need += Manifest.permission.POST_NOTIFICATIONS
        if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), REQ_PERM) else requestProjection()
    }

    @Deprecated("Deprecated in Java")
    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (code == REQ_PERM) {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) requestProjection()
            else Toast.makeText(this, "Cần quyền ghi âm để nghe âm thanh hệ thống", Toast.LENGTH_SHORT).show()
        }
    }

    private fun requestProjection() {
        val mpm = getSystemService(MediaProjectionManager::class.java)
        @Suppress("DEPRECATION")
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_PROJECTION)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_PROJECTION && resultCode == RESULT_OK && data != null) CaptureService.start(this, resultCode, data)
    }

    private fun showSettings() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        val audd = EditText(this).apply { hint = "AudD API key (nhận diện bài hát)"; setText(Prefs.rawAudd(this@MainActivity)); isSingleLine = true }
        val yt = EditText(this).apply { hint = "YouTube Data API key (video)"; setText(Prefs.rawYt(this@MainActivity)); isSingleLine = true }
        box.addView(audd); box.addView(yt)
        AlertDialog.Builder(this)
            .setTitle("Cài đặt")
            .setMessage("Key để trống = dùng key lúc build. Không có YouTube key thì app hiện ảnh bìa thay video.")
            .setView(box)
            .setPositiveButton("Lưu") { _, _ ->
                Prefs.setKeys(this, audd.text.toString(), yt.text.toString())
                videoKey = ""; onTrack(track)
            }
            .setNegativeButton("Hủy", null)
            .show()
    }

    companion object {
        private const val REQ_PERM = 1
        private const val REQ_PROJECTION = 2
    }
}
