package com.leveron.app

import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.net.Uri
import android.os.SystemClock
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request

/**
 * Lắng nghe MediaSession của mọi app đang phát nhạc (Spotify, YouTube Music, Zing...)
 * để biết bài hát, vị trí, trạng thái phát/dừng, và điều khiển tua / phát / dừng / next / prev.
 * Cần quyền "Truy cập thông báo" (NotificationListener).
 */
object MediaHub {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val http = OkHttpClient()

    private val _track = MutableStateFlow(Track())
    val track: StateFlow<Track> = _track

    /** Bài nhận diện từ âm thanh (dùng khi không có MediaSession). */
    private var recognized: Track? = null

    private lateinit var app: Context
    private var started = false
    private var current: MediaController? = null
    private var artJob: Job? = null
    private var lastArtKey = ""
    private var lastArt: Bitmap? = null

    private val callback = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) = rebuild()
        override fun onPlaybackStateChanged(state: PlaybackState?) {
            // Có thể một session khác vừa bắt đầu phát.
            refreshSessions()
        }
        override fun onSessionDestroyed() = refreshSessions()
    }

    private val sessionsListener = MediaSessionManager.OnActiveSessionsChangedListener { list ->
        pick(list ?: emptyList())
    }

    /** @return false nếu chưa được cấp quyền truy cập thông báo. */
    fun start(context: Context): Boolean {
        app = context.applicationContext
        val msm = app.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
        val comp = ComponentName(app, NotificationListener::class.java)
        return try {
            if (!started) {
                msm.addOnActiveSessionsChangedListener(sessionsListener, comp)
                started = true
            }
            pick(msm.getActiveSessions(comp))
            true
        } catch (e: SecurityException) {
            false
        }
    }

    fun stop() {
        if (!started) return
        val msm = app.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
        msm.removeOnActiveSessionsChangedListener(sessionsListener)
        current?.unregisterCallback(callback)
        current = null
        started = false
    }

    private fun refreshSessions() {
        if (!started) return
        val msm = app.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
        try {
            pick(msm.getActiveSessions(ComponentName(app, NotificationListener::class.java)))
        } catch (_: SecurityException) {
        }
    }

    private fun pick(list: List<MediaController>) {
        val usable = list.filter { it.packageName != app.packageName }
        val best = usable.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: usable.firstOrNull { it.packageName == current?.packageName }
            ?: usable.firstOrNull { it.metadata != null }
        if (best?.sessionToken != current?.sessionToken) {
            current?.unregisterCallback(callback)
            current = best
            best?.registerCallback(callback)
        }
        rebuild()
    }

    private fun rebuild() {
        val c = current
        val md = c?.metadata
        val title = md?.getString(MediaMetadata.METADATA_KEY_TITLE).orEmpty()
        if (c == null || title.isBlank()) {
            // Không có session hợp lệ → dùng bài nhận diện (nếu có).
            _track.value = recognized ?: Track()
            return
        }
        val st = c.playbackState
        val artist = md?.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: md?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST) ?: ""
        val album = md?.getString(MediaMetadata.METADATA_KEY_ALBUM).orEmpty()
        val key = "${c.packageName}|$artist|$title"
        val bmp = md?.let {
            it.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
                ?: it.getBitmap(MediaMetadata.METADATA_KEY_ART)
                ?: it.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
        }
        val art = bmp ?: if (key == lastArtKey) lastArt else null
        val actions = st?.actions ?: 0L
        val t = Track(
            title = title,
            artist = artist,
            album = album,
            art = art,
            playing = st?.state == PlaybackState.STATE_PLAYING || st?.state == PlaybackState.STATE_BUFFERING,
            durationMs = md?.getLong(MediaMetadata.METADATA_KEY_DURATION)?.coerceAtLeast(0) ?: 0,
            positionMs = st?.position?.coerceAtLeast(0) ?: 0,
            stamp = st?.lastPositionUpdateTime?.takeIf { it > 0 } ?: SystemClock.elapsedRealtime(),
            speed = st?.playbackSpeed?.takeIf { it > 0f } ?: 1f,
            packageName = c.packageName,
            appLabel = labelOf(c.packageName),
            controllable = true,
            canSeek = actions and PlaybackState.ACTION_SEEK_TO != 0L,
        )
        _track.value = t
        if (bmp != null) {
            lastArtKey = key; lastArt = bmp
        } else if (art == null) {
            loadArtFromUri(key, md)
        }
    }

    private fun loadArtFromUri(key: String, md: MediaMetadata?) {
        val uri = listOf(
            MediaMetadata.METADATA_KEY_ART_URI,
            MediaMetadata.METADATA_KEY_ALBUM_ART_URI,
            MediaMetadata.METADATA_KEY_DISPLAY_ICON_URI,
        ).firstNotNullOfOrNull { md?.getString(it)?.takeIf { s -> s.isNotBlank() } } ?: return
        artJob?.cancel()
        artJob = scope.launch {
            val bmp = withContext(Dispatchers.IO) { fetchBitmap(uri) } ?: return@launch
            lastArtKey = key; lastArt = bmp
            val cur = _track.value
            if ("${cur.packageName}|${cur.artist}|${cur.title}" == key) _track.value = cur.copy(art = bmp)
        }
    }

    internal fun fetchBitmap(uri: String): Bitmap? = try {
        if (uri.startsWith("http")) {
            http.newCall(Request.Builder().url(uri).build()).execute().use { r ->
                r.body?.byteStream()?.let { BitmapFactory.decodeStream(it) }
            }
        } else {
            app.contentResolver.openInputStream(Uri.parse(uri))?.use { BitmapFactory.decodeStream(it) }
        }
    } catch (_: Exception) {
        null
    }

    private fun labelOf(pkg: String): String = try {
        val pm = app.packageManager
        pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
    } catch (_: Exception) {
        pkg
    }

    // ---- Nhận diện từ âm thanh ----
    fun setRecognized(t: Track?) {
        recognized = t
        rebuild()
    }

    // ---- Điều khiển ----
    fun play() = current?.transportControls?.play()
    fun pause() = current?.transportControls?.pause()
    fun toggle() { if (_track.value.playing) pause() else play() }
    fun next() = current?.transportControls?.skipToNext()
    fun prev() = current?.transportControls?.skipToPrevious()
    fun seekTo(ms: Long) = current?.transportControls?.seekTo(ms)
}
