package com.leveron.app

import android.content.IntentFilter
import android.media.audiofx.AudioEffect
import android.os.Build
import android.service.notification.NotificationListenerService

/**
 * Không xử lý thông báo; chỉ cần được cấp quyền để đọc MediaSession,
 * và giữ tiến trình sống để EQ tiếp tục áp lên audio session của app khác.
 */
class NotificationListener : NotificationListenerService() {
    private val receiver = EffectSessionReceiver()

    override fun onCreate() {
        super.onCreate()
        EqEngine.init(this)
        val f = IntentFilter().apply {
            addAction(AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION)
            addAction(AudioEffect.ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION)
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, f, RECEIVER_EXPORTED)
        else registerReceiver(receiver, f)
    }

    override fun onListenerConnected() {
        MediaHub.start(this)
    }

    override fun onDestroy() {
        try { unregisterReceiver(receiver) } catch (_: Exception) {}
        super.onDestroy()
    }
}
