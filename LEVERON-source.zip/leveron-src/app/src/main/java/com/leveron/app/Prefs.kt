package com.leveron.app

import android.content.Context

/** Cài đặt người dùng (key API nhập trong app sẽ ghi đè key lúc build). */
object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("leveron", Context.MODE_PRIVATE)

    fun auddKey(c: Context): String = sp(c).getString("audd", "").orEmpty().ifBlank { BuildConfig.AUDD_API_KEY }
    fun youtubeKey(c: Context): String = sp(c).getString("yt", "").orEmpty().ifBlank { BuildConfig.YOUTUBE_API_KEY }
    fun setKeys(c: Context, audd: String, yt: String) =
        sp(c).edit().putString("audd", audd.trim()).putString("yt", yt.trim()).apply()
    fun rawAudd(c: Context) = sp(c).getString("audd", "").orEmpty()
    fun rawYt(c: Context) = sp(c).getString("yt", "").orEmpty()

    fun showVideo(c: Context) = sp(c).getBoolean("video", true)
    fun setShowVideo(c: Context, v: Boolean) = sp(c).edit().putBoolean("video", v).apply()

    /** Độ lệch video (ms) để căn khớp với âm thanh. */
    /** Độ lệch riêng cho từng video (nhớ lại, chỉ cần chỉnh một lần). */
    fun videoOffset(c: Context, videoId: String) = sp(c).getInt("voff_$videoId", 0)
    fun setVideoOffset(c: Context, videoId: String, v: Int) = sp(c).edit().putInt("voff_$videoId", v).apply()

    /** Video người dùng đã chọn cho một bài. */
    fun pick(c: Context, songKey: String): String = sp(c).getString("pick_$songKey", "").orEmpty()
    fun setPick(c: Context, songKey: String, id: String) = sp(c).edit().putString("pick_$songKey", id).apply()

    fun eqGains(c: Context): FloatArray {
        val s = sp(c).getString("eq", null) ?: return FloatArray(EqEngine.BANDS)
        val p = s.split(",").mapNotNull { it.toFloatOrNull() }
        return if (p.size == EqEngine.BANDS) p.toFloatArray() else FloatArray(EqEngine.BANDS)
    }
    fun setEqGains(c: Context, g: FloatArray) = sp(c).edit().putString("eq", g.joinToString(",")).apply()
    fun eqEnabled(c: Context) = sp(c).getBoolean("eq_on", true)
    fun setEqEnabled(c: Context, v: Boolean) = sp(c).edit().putBoolean("eq_on", v).apply()
    fun eqPreset(c: Context) = sp(c).getString("eq_preset", "Flat").orEmpty()
    fun setEqPreset(c: Context, v: String) = sp(c).edit().putString("eq_preset", v).apply()
}
