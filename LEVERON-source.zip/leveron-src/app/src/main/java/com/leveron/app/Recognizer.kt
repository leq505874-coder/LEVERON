package com.leveron.app

import android.os.SystemClock
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.TimeUnit

object RecognizeState {
    private val _status = MutableStateFlow("")
    val status: StateFlow<String> = _status
    val busy = MutableStateFlow(false)
    fun say(s: String) { _status.value = s }
}

/** Nhận diện bài hát bằng AudD từ đoạn PCM thu từ âm thanh hệ thống. */
object Recognizer {
    const val SAMPLE_RATE = 44100
    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS).writeTimeout(30, TimeUnit.SECONDS).build()

    fun wav(pcm: ByteArray): ByteArray {
        val bb = ByteBuffer.allocate(44 + pcm.size).order(ByteOrder.LITTLE_ENDIAN)
        bb.put("RIFF".toByteArray()).putInt(36 + pcm.size).put("WAVE".toByteArray())
        bb.put("fmt ".toByteArray()).putInt(16).putShort(1).putShort(1)
            .putInt(SAMPLE_RATE).putInt(SAMPLE_RATE * 2).putShort(2).putShort(16)
        bb.put("data".toByteArray()).putInt(pcm.size).put(pcm)
        return bb.array()
    }

    /** @param startedAt thời điểm (elapsedRealtime) bắt đầu thu. */
    suspend fun identify(token: String, pcm: ByteArray, startedAt: Long): Result<Track> = withContext(Dispatchers.IO) {
        runCatching {
            val body = MultipartBody.Builder().setType(MultipartBody.FORM)
                .addFormDataPart("api_token", token)
                .addFormDataPart("return", "apple_music,spotify")
                .addFormDataPart("file", "audio.wav", wav(pcm).toRequestBody("audio/wav".toMediaType()))
                .build()
            val json = http.newCall(Request.Builder().url("https://api.audd.io/").post(body).build()).execute().use {
                JSONObject(it.body?.string().orEmpty())
            }
            if (json.optString("status") != "success") {
                error(json.optJSONObject("error")?.optString("error_message") ?: "AudD lỗi")
            }
            val r = json.optJSONObject("result") ?: error("Không nhận ra bài hát này")
            val apple = r.optJSONObject("apple_music")
            val spotify = r.optJSONObject("spotify")
            val artUrl = apple?.optJSONObject("artwork")?.optString("url")?.replace("{w}", "600")?.replace("{h}", "600")
                ?: spotify?.optJSONObject("album")?.optJSONArray("images")?.optJSONObject(0)?.optString("url")
            val art = artUrl?.takeIf { it.isNotBlank() }?.let { MediaHub.fetchBitmap(it) }
            val dur = apple?.optLong("durationMillis", 0)?.takeIf { it > 0 }
                ?: spotify?.optLong("duration_ms", 0) ?: 0L
            Track(
                title = r.optString("title"),
                artist = r.optString("artist"),
                album = r.optString("album"),
                art = art,
                playing = true,
                durationMs = dur,
                positionMs = parseTimecode(r.optString("timecode")),
                stamp = startedAt,
                recognized = true,
                appLabel = "Nhận diện âm thanh",
            )
        }
    }

    private fun parseTimecode(s: String): Long {
        val p = s.split(":").mapNotNull { it.toIntOrNull() }
        return when (p.size) { 2 -> (p[0] * 60 + p[1]) * 1000L; 3 -> (p[0] * 3600 + p[1] * 60 + p[2]) * 1000L; else -> 0L }
    }
}
