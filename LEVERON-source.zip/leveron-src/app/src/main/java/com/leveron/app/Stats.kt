package com.leveron.app

import android.content.Context
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * Thống kê thời gian BẠN nghe từng ca sĩ (lưu trên máy, theo ngày).
 * Bài có nhiều ca sĩ (a, b & c) thì mỗi ca sĩ được cộng đủ thời gian nghe bài đó.
 */
object Stats {
    private lateinit var app: Context
    private var loaded = false
    private var dirty = false
    private val data = HashMap<String, HashMap<String, Long>>() // ngày → ca sĩ → ms
    private val dayFmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    @Synchronized
    fun init(c: Context) {
        if (loaded) return
        app = c.applicationContext
        runCatching {
            val o = JSONObject(app.getSharedPreferences("leveron_stats", Context.MODE_PRIVATE).getString("d", "{}") ?: "{}")
            for (day in o.keys()) {
                val m = HashMap<String, Long>()
                val a = o.getJSONObject(day)
                for (k in a.keys()) m[k] = a.getLong(k)
                data[day] = m
            }
        }
        loaded = true
    }

    fun split(artist: String): List<String> =
        artist.split(',', '&', ';', '/').map { it.trim() }.filter { it.isNotEmpty() }.distinct()

    @Synchronized
    fun add(artists: List<String>, ms: Long) {
        if (!loaded || artists.isEmpty() || ms <= 0) return
        val m = data.getOrPut(dayFmt.format(Date())) { HashMap() }
        for (a in artists) m[a] = (m[a] ?: 0L) + ms
        dirty = true
    }

    @Synchronized
    fun flush() {
        if (!loaded || !dirty) return
        // Giữ tối đa 400 ngày gần nhất.
        val keep = data.keys.sortedDescending().take(400).toSet()
        data.keys.retainAll(keep)
        val o = JSONObject()
        for ((day, m) in data) o.put(day, JSONObject(m as Map<*, *>))
        app.getSharedPreferences("leveron_stats", Context.MODE_PRIVATE).edit().putString("d", o.toString()).apply()
        dirty = false
    }

    /** Tổng thời gian nghe theo ca sĩ trong [days] ngày gần nhất (0 = tất cả), giảm dần. */
    @Synchronized
    fun top(days: Int): List<Pair<String, Long>> {
        val allowed: Set<String>? = if (days <= 0) null else {
            val cal = Calendar.getInstance()
            HashSet<String>().also { s -> repeat(days) { s.add(dayFmt.format(cal.time)); cal.add(Calendar.DAY_OF_YEAR, -1) } }
        }
        val sum = HashMap<String, Long>()
        for ((day, m) in data) {
            if (allowed != null && day !in allowed) continue
            for ((a, v) in m) sum[a] = (sum[a] ?: 0L) + v
        }
        return sum.entries.map { it.key to it.value }.sortedByDescending { it.second }
    }

    fun clear() = synchronized(this) {
        data.clear(); dirty = true; flush()
    }

    fun fmt(ms: Long): String {
        val s = ms / 1000
        val h = s / 3600; val m = (s % 3600) / 60; val sec = s % 60
        return when {
            h > 0 -> "%dg %02dp".format(h, m)
            m > 0 -> "%dp %02ds".format(m, sec)
            else -> "%ds".format(sec)
        }
    }
}
