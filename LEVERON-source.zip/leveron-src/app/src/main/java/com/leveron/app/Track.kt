package com.leveron.app

import android.graphics.Bitmap
import android.os.SystemClock

/** Trạng thái bài hát đang phát (từ MediaSession của app khác hoặc từ nhận diện âm thanh). */
data class Track(
    val title: String = "",
    val artist: String = "",
    val album: String = "",
    val art: Bitmap? = null,
    val playing: Boolean = false,
    val durationMs: Long = 0,
    /** Vị trí tại thời điểm [stamp] (SystemClock.elapsedRealtime). */
    val positionMs: Long = 0,
    val stamp: Long = SystemClock.elapsedRealtime(),
    val speed: Float = 1f,
    val packageName: String = "",
    val appLabel: String = "",
    /** true nếu có thể điều khiển (tua/phát/dừng/next/prev) qua MediaSession. */
    val controllable: Boolean = false,
    val recognized: Boolean = false,
    val canSeek: Boolean = false,
) {
    val hasTrack get() = title.isNotBlank()
    val key get() = "$artist|$title"

    fun position(now: Long = SystemClock.elapsedRealtime()): Long {
        var p = positionMs
        if (playing) p += ((now - stamp) * speed).toLong()
        if (durationMs > 0) p = p.coerceAtMost(durationMs)
        return p.coerceAtLeast(0)
    }
}
