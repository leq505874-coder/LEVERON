package com.leveron.app

import android.annotation.SuppressLint
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.view.MotionEvent
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.widget.FrameLayout

/**
 * Phát video YouTube (IFrame API) ở chế độ TẮT TIẾNG và tự đồng bộ theo vị trí bài hát,
 * vì âm thanh thật vẫn do app nguồn phát.
 */
@SuppressLint("SetJavaScriptEnabled", "ClickableViewAccessibility")
class VideoPlayerView(c: Context) : FrameLayout(c) {
    var onError: (() -> Unit)? = null
    var onPlaying: (() -> Unit)? = null
    private val ui = Handler(Looper.getMainLooper())
    private val web = WebView(c)

    inner class Bridge {
        @JavascriptInterface fun error(code: Int) { ui.post { onError?.invoke() } }
        @JavascriptInterface fun playing() { ui.post { onPlaying?.invoke() } }
    }

    init {
        setBackgroundColor(0xFF000000.toInt())
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.setBackgroundColor(0)
        web.addJavascriptInterface(Bridge(), "Android")
        web.setOnTouchListener { _, e -> e.actionMasked != MotionEvent.ACTION_CANCEL } // chặn chạm vào player
        addView(web, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
        web.loadDataWithBaseURL("https://leveron.app/", HTML, "text/html", "utf-8", null)
    }

    private fun js(code: String) = web.evaluateJavascript(code, null)

    fun load(videoId: String, startMs: Long, play: Boolean) =
        js("load('$videoId',${startMs / 1000.0},$play)")

    fun sync(posMs: Long, play: Boolean, force: Boolean = false) =
        js("sync(${posMs / 1000.0},$play,$force)")

    fun stop() = js("stopVideo()")

    fun release() {
        web.stopLoading(); removeView(web); web.destroy()
    }

    companion object {
        private const val HTML = """<!DOCTYPE html><html><head><meta name="viewport" content="width=device-width,initial-scale=1">
<style>html,body{margin:0;height:100%;background:#000;overflow:hidden}#p,iframe{width:100%;height:100%;border:0}</style></head>
<body><div id="p"></div>
<script src="https://www.youtube.com/iframe_api"></script>
<script>
var player=null,ready=false,pending=null;
function onYouTubeIframeAPIReady(){
  player=new YT.Player('p',{width:'100%',height:'100%',
    playerVars:{controls:0,disablekb:1,fs:0,modestbranding:1,playsinline:1,rel:0,iv_load_policy:3,origin:'https://leveron.app'},
    events:{
      onReady:function(){ready=true;player.mute();nocc();if(pending){load(pending[0],pending[1],pending[2]);pending=null;}},
      onStateChange:function(e){if(e.data===1||e.data===5){nocc();Android.playing();}},
      onError:function(e){Android.error(e.data);}
    }});
}
function load(id,t,play){
  if(!ready){pending=[id,t,play];return;}
  player.mute();
  if(play)player.loadVideoById({videoId:id,startSeconds:t});else player.cueVideoById({videoId:id,startSeconds:t});
}
function sync(t,play,force){
  if(!ready||!player.getCurrentTime)return;
  var st=player.getPlayerState();
  if(force||Math.abs(player.getCurrentTime()-t)>0.8)player.seekTo(t,true);
  if(play&&st!==1&&st!==3)player.playVideo();
  if(!play&&st===1)player.pauseVideo();
}
function nocc(){try{player.unloadModule('captions');player.unloadModule('cc');}catch(x){}}
function stopVideo(){if(ready)player.stopVideo();}
</script></body></html>"""
    }
}
