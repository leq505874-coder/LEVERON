package com.leveron.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.text.Normalizer
import kotlin.math.abs

/**
 * Tìm video lyric YouTube của bài hát (YouTube Data API v3, cần API key).
 * Chấm điểm từng kết quả: khớp tên bài → khớp nghệ sĩ/kênh → không phải cover/remix/live
 * → độ dài gần với bài đang phát (đỡ lệch) → có chữ "lyrics".
 */
object VideoResolver {
    private val http = OkHttpClient()
    private val cache = HashMap<String, List<String>>()
    private val ISO = Regex("PT(?:(\\d+)H)?(?:(\\d+)M)?(?:(\\d+)S)?")
    private val BAD = listOf(
        "cover", "remix", "live", "karaoke", "instrumental", "beat", "reaction", "nightcore",
        "sped up", "slowed", "reverb", "8d", "piano", "guitar", "acoustic", "lofi", "lo-fi", "tutorial", "mashup", "shorts"
    )

    private fun get(url: okhttp3.HttpUrl): JSONObject =
        http.newCall(Request.Builder().url(url).build()).execute().use { JSONObject(it.body?.string().orEmpty()) }

    private fun parseIso(s: String): Long {
        val m = ISO.matchEntire(s) ?: return 0
        val h = m.groupValues[1].toLongOrNull() ?: 0
        val mi = m.groupValues[2].toLongOrNull() ?: 0
        val se = m.groupValues[3].toLongOrNull() ?: 0
        return (h * 3600 + mi * 60 + se) * 1000
    }

    /** Bỏ dấu, chữ thường, chỉ giữ chữ-số: "Ở ĐÂY" → "o day" → "oday". */
    private fun norm(s: String): String =
        Normalizer.normalize(s.lowercase().replace('đ', 'd'), Normalizer.Form.NFD)
            .replace(Regex("\\p{M}+"), "").replace(Regex("[^a-z0-9]+"), "")

    private class Cand(val id: String, val title: String, val channel: String)

    suspend fun find(apiKey: String, artist: String, title: String, durationMs: Long = 0): List<String> {
        if (apiKey.isBlank() || title.isBlank()) return emptyList()
        val key = "$artist|$title"
        cache[key]?.let { return it }
        val ids = withContext(Dispatchers.IO) {
            runCatching {
                val firstArtist = artist.split(',', '&', ';').firstOrNull()?.trim().orEmpty()
                val search = "https://www.googleapis.com/youtube/v3/search".toHttpUrl().newBuilder()
                    .addQueryParameter("part", "snippet")
                    .addQueryParameter("q", "$firstArtist $title lyrics")
                    .addQueryParameter("type", "video")
                    .addQueryParameter("videoEmbeddable", "true")
                    .addQueryParameter("videoSyndicated", "true")
                    .addQueryParameter("maxResults", "15")
                    .addQueryParameter("key", apiKey)
                    .build()
                val items = get(search).optJSONArray("items") ?: return@runCatching emptyList<String>()
                val cands = List(items.length()) {
                    val o = items.getJSONObject(it)
                    val sn = o.getJSONObject("snippet")
                    Cand(o.getJSONObject("id").getString("videoId"), sn.optString("title"), sn.optString("channelTitle"))
                }
                if (cands.isEmpty()) return@runCatching emptyList<String>()

                val len = HashMap<String, Long>()
                if (durationMs > 0) {
                    val vids = "https://www.googleapis.com/youtube/v3/videos".toHttpUrl().newBuilder()
                        .addQueryParameter("part", "contentDetails")
                        .addQueryParameter("id", cands.joinToString(",") { it.id })
                        .addQueryParameter("key", apiKey)
                        .build()
                    val arr = get(vids).optJSONArray("items")
                    for (i in 0 until (arr?.length() ?: 0)) {
                        val o = arr!!.getJSONObject(i)
                        len[o.getString("id")] = parseIso(o.getJSONObject("contentDetails").optString("duration"))
                    }
                }

                val song = norm(title.replace(Regex("[\\(\\[].*?[\\)\\]]"), ""))
                val artistParts = artist.split(',', '&', ';', '/').map { norm(it) }.filter { it.length >= 3 }
                val userBadInTitle = norm(title)

                fun score(c: Cand): List<Int> {
                    val t = norm(c.title); val ch = norm(c.channel)
                    val titleMatch = song.isNotEmpty() && t.contains(song)
                    val artistMatch = artistParts.any { t.contains(it) || ch.contains(it) }
                    val low = c.title.lowercase()
                    // Chỉ phạt từ "xấu" nếu bài gốc không chứa nó (vd bài tên "Live").
                    val bad = BAD.any { low.contains(it) && !userBadInTitle.contains(norm(it)) }
                    val diff = len[c.id]?.let { abs(it - durationMs) } ?: 60_000L
                    val lyric = low.contains("lyric") || low.contains("lời") || low.contains("loi bai hat") || low.contains("kara")
                    return listOf(
                        if (titleMatch) 0 else 1,
                        if (bad) 1 else 0,
                        if (artistMatch) 0 else 1,
                        (diff / 4000).toInt().coerceAtMost(15),
                        if (lyric) 0 else 1,
                    )
                }

                val cmp = Comparator<Cand> { a, b ->
                    val x = score(a); val y = score(b)
                    for (i in x.indices) if (x[i] != y[i]) return@Comparator x[i].compareTo(y[i])
                    0
                }
                cands.sortedWith(cmp).map { it.id }
            }.getOrDefault(emptyList())
        }
        if (ids.isNotEmpty()) cache[key] = ids
        return ids
    }
}
