package com.leveron.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject

/** Tìm video YouTube của bài hát qua YouTube Data API v3 (cần API key). */
object VideoResolver {
    private val http = OkHttpClient()
    private val cache = HashMap<String, List<String>>()

    suspend fun find(apiKey: String, artist: String, title: String): List<String> {
        if (apiKey.isBlank() || title.isBlank()) return emptyList()
        val key = "$artist|$title"
        cache[key]?.let { return it }
        val ids = withContext(Dispatchers.IO) {
            runCatching {
                val url = "https://www.googleapis.com/youtube/v3/search".toHttpUrl().newBuilder()
                    .addQueryParameter("part", "snippet")
                    .addQueryParameter("q", "$artist $title official music video")
                    .addQueryParameter("type", "video")
                    .addQueryParameter("videoEmbeddable", "true")
                    .addQueryParameter("videoSyndicated", "true")
                    .addQueryParameter("maxResults", "5")
                    .addQueryParameter("key", apiKey)
                    .build()
                http.newCall(Request.Builder().url(url).build()).execute().use { r ->
                    val items = JSONObject(r.body?.string().orEmpty()).optJSONArray("items")
                    List(items?.length() ?: 0) { items!!.getJSONObject(it).getJSONObject("id").getString("videoId") }
                }
            }.getOrDefault(emptyList())
        }
        if (ids.isNotEmpty()) cache[key] = ids
        return ids
    }
}
