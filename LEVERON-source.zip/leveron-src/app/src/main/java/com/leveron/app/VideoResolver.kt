package com.leveron.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import kotlin.math.abs

/**
 * Tìm video lyric YouTube của bài hát (YouTube Data API v3, cần API key).
 * Ưu tiên video có độ dài gần nhất với bài đang phát để đỡ lệch với âm thanh.
 */
object VideoResolver {
    private val http = OkHttpClient()
    private val cache = HashMap<String, List<String>>()
    private val ISO = Regex("PT(?:(\\d+)H)?(?:(\\d+)M)?(?:(\\d+)S)?")

    private fun get(url: okhttp3.HttpUrl): JSONObject =
        http.newCall(Request.Builder().url(url).build()).execute().use { JSONObject(it.body?.string().orEmpty()) }

    private fun parseIso(s: String): Long {
        val m = ISO.matchEntire(s) ?: return 0
        val h = m.groupValues[1].toLongOrNull() ?: 0
        val mi = m.groupValues[2].toLongOrNull() ?: 0
        val se = m.groupValues[3].toLongOrNull() ?: 0
        return (h * 3600 + mi * 60 + se) * 1000
    }

    suspend fun find(apiKey: String, artist: String, title: String, durationMs: Long = 0): List<String> {
        if (apiKey.isBlank() || title.isBlank()) return emptyList()
        val key = "$artist|$title"
        cache[key]?.let { return it }
        val ids = withContext(Dispatchers.IO) {
            runCatching {
                val search = "https://www.googleapis.com/youtube/v3/search".toHttpUrl().newBuilder()
                    .addQueryParameter("part", "snippet")
                    .addQueryParameter("q", "$artist $title lyrics")
                    .addQueryParameter("type", "video")
                    .addQueryParameter("videoEmbeddable", "true")
                    .addQueryParameter("videoSyndicated", "true")
                    .addQueryParameter("maxResults", "10")
                    .addQueryParameter("key", apiKey)
                    .build()
                val items = get(search).optJSONArray("items")
                val found = List(items?.length() ?: 0) { items!!.getJSONObject(it).getJSONObject("id").getString("videoId") }
                if (durationMs <= 0 || found.size < 2) return@runCatching found

                // Lấy độ dài từng video, xếp theo độ chênh so với bài hát.
                val vids = "https://www.googleapis.com/youtube/v3/videos".toHttpUrl().newBuilder()
                    .addQueryParameter("part", "contentDetails")
                    .addQueryParameter("id", found.joinToString(","))
                    .addQueryParameter("key", apiKey)
                    .build()
                val arr = get(vids).optJSONArray("items") ?: return@runCatching found
                val len = HashMap<String, Long>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    len[o.getString("id")] = parseIso(o.getJSONObject("contentDetails").optString("duration"))
                }
                found.sortedBy { id -> len[id]?.let { abs(it - durationMs) } ?: Long.MAX_VALUE }
            }.getOrDefault(emptyList())
        }
        if (ids.isNotEmpty()) cache[key] = ids
        return ids
    }
}
