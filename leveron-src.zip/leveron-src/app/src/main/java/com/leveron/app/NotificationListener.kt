package com.leveron.app

import android.service.notification.NotificationListenerService

class NotificationListener : NotificationListenerService()
